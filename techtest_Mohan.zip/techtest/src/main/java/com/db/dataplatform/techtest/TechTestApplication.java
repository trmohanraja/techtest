package com.db.dataplatform.techtest;

import static com.db.dataplatform.techtest.config.Constant.BLOCK_INPUT1;
import static com.db.dataplatform.techtest.config.Constant.BLOCK_INPUT2;

import java.io.UnsupportedEncodingException;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.retry.annotation.EnableRetry;

import com.db.dataplatform.techtest.client.api.model.DataBody;
import com.db.dataplatform.techtest.client.api.model.DataEnvelope;
import com.db.dataplatform.techtest.client.api.model.DataHeader;
import com.db.dataplatform.techtest.client.component.Client;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.fasterxml.jackson.core.JsonProcessingException;

@SpringBootApplication
@EnableRetry
public class TechTestApplication {

	public static final String HEADER_NAME = "TSLA-USDGBP-10Y";
	public static final String MD5_CHECKSUM = "cecfd3953783df706878aaec2c22aa70";

	@Autowired
	private Client client;

	public static void main(String[] args) {

		SpringApplication.run(TechTestApplication.class, args);
	}

	@EventListener(ApplicationReadyEvent.class)
	public void initiatePushDataFlow() throws JsonProcessingException, UnsupportedEncodingException {
		pushData(BLOCK_INPUT1, HEADER_NAME);
		pushData(BLOCK_INPUT2, HEADER_NAME + 1101);
		queryData();

		updateData();
	}

	private void updateData() throws UnsupportedEncodingException {
		client.updateData(HEADER_NAME, BlockTypeEnum.BLOCKTYPEB.name());
	}

	private void queryData() throws JsonProcessingException {

		IntStream.range(0, 10).forEach(nbr -> {
			try {
				pushData(BLOCK_INPUT1 + nbr, HEADER_NAME + nbr);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		});

		client.getData(BlockTypeEnum.BLOCKTYPEA.toString());
	}

	private void pushData(String inData, String headerName) throws JsonProcessingException {

		DataBody dataBody = new DataBody(inData);

		DataHeader dataHeader = new DataHeader(headerName, BlockTypeEnum.BLOCKTYPEA, MD5_CHECKSUM);

		DataEnvelope dataEnvelope = new DataEnvelope(dataHeader, dataBody);

		client.pushData(dataEnvelope);

	}

}
