package com.db.dataplatform.techtest.server.component.impl;

import org.springframework.stereotype.Component;

import com.db.dataplatform.techtest.server.component.HadoopClient;
import com.db.dataplatform.techtest.server.exception.HadoopClientException;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class HadoopClientImpl implements HadoopClient {

    public static final String URI_PUSHBIGDATA = "http://localhost:8090/hadoopserver/pushbigdata";

    @Override
    public void saveBigData(String payload) throws HadoopClientException {
        log.info("Calling Hadoop API");
    }
}
