package com.db.dataplatform.techtest.client.component.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.db.dataplatform.techtest.client.api.model.DataEnvelope;
import com.db.dataplatform.techtest.client.component.Client;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Client code does not require any test coverage
 */

@Service
@Slf4j
@RequiredArgsConstructor
public class ClientImpl implements Client {

	private final RestTemplate restTemplate;
	// private final HbaseTemplate hbaseTemplate;
	@Value("${service.base.url}")
	private String baseUrl;

	@Value("${hadoop.base.url}")
	private String hadoopBaseUrl;

	@Override
	public boolean pushData(DataEnvelope dataEnvelope) {
		log.info("Pushing data {} to {}", dataEnvelope.getDataHeader().getName(), baseUrl + "pushdata");
		boolean checksumPassed = restTemplate.postForObject(baseUrl + "pushdata", dataEnvelope, Boolean.class);
		HttpEntity<String> request = new HttpEntity<>(new String(dataEnvelope.toString()));
		restTemplate.postForObject(hadoopBaseUrl + "pushbigdata", request, String.class);
		return checksumPassed;
	}

	@Override
	public List<DataEnvelope> getData(String blockType) {
		log.info("GetData for the header block type {}", blockType);
		ResponseEntity<List<DataEnvelope>> dataBlockListResponse = restTemplate.exchange(
				baseUrl + "datablock/" + blockType, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<DataEnvelope>>() {
				});
		return dataBlockListResponse.getBody();
	}

	@Override
	public boolean updateData(String blockName, String newBlockType) {
		log.info("Blocktype to {} with name {}", newBlockType, blockName);

		ResponseEntity<Boolean> response = restTemplate.exchange(baseUrl + "update/" + blockName + "/" + newBlockType,
				HttpMethod.PATCH, new HttpEntity<String>(newBlockType), Boolean.class);
		return response.getStatusCode() == HttpStatus.OK ? true : false;
	}

}
