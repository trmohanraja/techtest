package com.db.dataplatform.techtest.server.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.persistence.repository.DataStoreRepository;
import com.db.dataplatform.techtest.server.service.DataBodyService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DataBodyServiceImpl implements DataBodyService {

	private final DataStoreRepository dataStoreRepository;

	@Override
	public DataBodyEntity saveDataBody(DataBodyEntity dataBody) {
		dataStoreRepository.save(dataBody);
		return dataStoreRepository.getOne(dataBody.getDataStoreId());
	}

	@Override
	public List<DataBodyEntity> getDataByBlockType(BlockTypeEnum blockType) {
		return dataStoreRepository.findByDataHeaderEntity_Blocktype(blockType);
	}

	/*
	 * @Override public Optional<DataBodyEntity> getDataByBlockName(String
	 * blockName) { return
	 * dataStoreRepository.findByDataHeaderEntity_Name(blockName); }
	 */

	@Override
	public DataBodyEntity updateDataBody(String blockName, BlockTypeEnum newType) {

		DataBodyEntity dataBodyEnt = dataStoreRepository.findByDataHeaderEntity_Name(blockName);
		DataHeaderEntity dataHeaderEntity = dataBodyEnt.getDataHeaderEntity();
		dataHeaderEntity.setBlocktype(newType);
		dataBodyEnt.setDataHeaderEntity(dataHeaderEntity);
		
		return dataStoreRepository.save(dataBodyEnt);
	}

	@Override
	public Optional<DataBodyEntity> getDataByBlockName(String blockName) {
		// TODO Auto-generated method stub
		return null;
	}
}
