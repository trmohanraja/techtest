package com.db.dataplatform.techtest.config;

public class Constant {

    public static final String BLOCK_INPUT1 = "AKCp5fU4WNWKBVvhXsbNhqk33tawri9iJUkA5o4A6YqpwvAoYjajVw8xdEw6r9796h1wEp29D";
    
    public static final String BLOCK_INPUT2 = "{ \"developers\": [{ \"firstName\":\"James\" , \"lastName\":\"Williamson\" }, " +
            "{ \"firstName\":\"Steve\" , \"lastName\":\"Walkman\" } ]}";
}
