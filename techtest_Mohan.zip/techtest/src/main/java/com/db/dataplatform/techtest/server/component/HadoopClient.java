package com.db.dataplatform.techtest.server.component;

import com.db.dataplatform.techtest.server.exception.HadoopClientException;

public interface HadoopClient {
    void saveBigData(String payload) throws HadoopClientException;
}
