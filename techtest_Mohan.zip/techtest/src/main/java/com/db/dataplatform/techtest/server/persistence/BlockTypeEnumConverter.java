package com.db.dataplatform.techtest.server.persistence;

import java.beans.PropertyEditorSupport;

public class BlockTypeEnumConverter extends PropertyEditorSupport {

	public void setAsText(final String text) throws IllegalArgumentException {
		setValue(BlockTypeEnum.fromValue(text));
	}

}
