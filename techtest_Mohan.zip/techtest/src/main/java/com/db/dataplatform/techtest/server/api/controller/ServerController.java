package com.db.dataplatform.techtest.server.api.controller;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnumConverter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/dataserver")
@RequiredArgsConstructor
@Validated
public class ServerController {

	private final Server server;

	@PostMapping(value = "/pushdata", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Boolean> pushData(@Valid @RequestBody DataEnvelope dataEnvelope)
			throws IOException, NoSuchAlgorithmException {

		log.info("Data envelope received: {}", dataEnvelope.getDataHeader().getName());
		boolean checksumPass = server.saveDataEnvelope(dataEnvelope);

		log.info("Data envelope persisted. Attribute name: {}", dataEnvelope.getDataHeader().getName());
		return ResponseEntity.ok(checksumPass);
	}

	@GetMapping(value = "/datablock/{type}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<DataEnvelope>> getBlockData(@PathVariable(value = "type") BlockTypeEnum blockType) {

		log.info("Get block data for the block type {}", blockType);

		List<DataEnvelope> list = server.getBlockList(blockType);

		return new ResponseEntity<List<DataEnvelope>>(list, HttpStatus.OK);
	}

	@PatchMapping(value = "/update/{name}/{newType}")
	public ResponseEntity<HttpStatus> updateData(@PathVariable(value = "name") @NotBlank @Size(max = 20) String name,
			@PathVariable(value = "newType") BlockTypeEnum newType) {
		boolean isUpdated = server.updateDataEnvelope(name, newType);
		log.info("Update the name {} to new block type {}", name, newType);
		return isUpdated == true ? ResponseEntity.ok().build()
				: ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).build();
	}

	@InitBinder
	public void initBinder(final WebDataBinder webdataBinder) {
		webdataBinder.registerCustomEditor(BlockTypeEnum.class, new BlockTypeEnumConverter());
	}

}
