package com.db.dataplatform.techtest.server.component.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import com.db.dataplatform.techtest.server.api.model.DataBody;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.service.DataBodyService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class ServerImpl implements Server {

	private final DataBodyService dataBodyServiceImpl;
	private final ModelMapper modelMapper;

	/**
	 * @param envelope
	 * @return true if there is a match with the client provided checksum.
	 */
	@Override
	public boolean saveDataEnvelope(DataEnvelope envelope) {
		return persist(envelope);
	}

	private boolean persist(DataEnvelope envelope) {

		DataBody dataBodyIn = envelope.getDataBody();
		log.info("Persisting data with attribute name: {}", envelope.getDataHeader().getName());
		DataHeaderEntity dataHeaderEntity = modelMapper.map(envelope.getDataHeader(), DataHeaderEntity.class);
		DataBodyEntity dataBodyEntity = modelMapper.map(
				new DataBody(DigestUtils.md5DigestAsHex(dataBodyIn.getDataBody().getBytes())), DataBodyEntity.class);
		dataBodyEntity.setDataHeaderEntity(dataHeaderEntity);

		DataBodyEntity responseEntity = saveData(dataBodyEntity);
		log.debug("Request Header CheckSum : {}", envelope.getDataHeader().getCheckSum());
		log.debug("Response Entity CheckSum : {}", responseEntity.getDataBody());
		return envelope.getDataHeader().getCheckSum().equals(responseEntity.getDataBody()) ? true : false;
	}

	private DataBodyEntity saveData(DataBodyEntity dataBodyEntity) {
		return dataBodyServiceImpl.saveDataBody(dataBodyEntity);
	}

	@Override
	public List<DataEnvelope> getBlockList(BlockTypeEnum blockType) {
		log.debug("Request to get blocklist for the blockType : {}", blockType);
		List<DataBodyEntity> entityList = dataBodyServiceImpl.getDataByBlockType(blockType);
		return entityList.stream().map(dataEnt -> modelMapper.map(dataEnt, DataEnvelope.class))
				.collect(Collectors.toList());
	}

	@Override
	public boolean updateDataEnvelope(String blockName, BlockTypeEnum newType) {
		log.debug("Update the block type of envelope : {}", blockName);
		dataBodyServiceImpl.updateDataBody(blockName, newType);
		return true;
	}
}
