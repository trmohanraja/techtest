package com.db.dataplatform.techtest.server.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;

@Repository
@Transactional
public interface DataHeaderRepository extends JpaRepository<DataHeaderEntity, Long> {

}
