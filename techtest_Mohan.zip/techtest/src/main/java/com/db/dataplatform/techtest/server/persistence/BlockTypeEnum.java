package com.db.dataplatform.techtest.server.persistence;

import java.util.Arrays;

public enum BlockTypeEnum {
	BLOCKTYPEA("blocktypea"),
	BLOCKTYPEB("blocktypeb");

	private final String type;

	BlockTypeEnum(String type) {
		this.type = type;
	}

	public static BlockTypeEnum fromValue(String value) {
		for (BlockTypeEnum blockType : values()) {
			if (blockType.type.equalsIgnoreCase(value)) {
				return blockType;
			}
		}
		throw new IllegalArgumentException(
				"Request enum type is Unknown " + value + ", the found values are " + Arrays.toString(values()));
	}

	@Override
	public String toString() {
		return type;
	}
}
