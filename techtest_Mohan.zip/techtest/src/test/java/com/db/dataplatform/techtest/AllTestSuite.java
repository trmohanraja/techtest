package com.db.dataplatform.techtest;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.db.dataplatform.techtest.api.controller.ServerControllerComponentTest;
import com.db.dataplatform.techtest.api.model.DataBodyTests;
import com.db.dataplatform.techtest.api.model.DataEnvelopeTests;
import com.db.dataplatform.techtest.api.model.DataHeaderTests;
import com.db.dataplatform.techtest.component.HadoopClientComponentTest;
import com.db.dataplatform.techtest.persistence.model.DataBodyEntityTests;
import com.db.dataplatform.techtest.persistence.model.DataHeaderEntityTests;
import com.db.dataplatform.techtest.service.DataBodyServiceTests;
import com.db.dataplatform.techtest.service.DataHeaderServiceTests;
import com.db.dataplatform.techtest.service.ServerServiceTests;

@RunWith(Suite.class)

@Suite.SuiteClasses({ ServerControllerComponentTest.class,
	DataBodyTests.class,
	DataEnvelopeTests.class,
	DataHeaderTests.class,
	DataBodyEntityTests.class,
	DataHeaderEntityTests.class,
	DataBodyServiceTests.class,
	DataHeaderServiceTests.class,
	ServerServiceTests.class,
	HadoopClientComponentTest.class
})
public class AllTestSuite {
}
