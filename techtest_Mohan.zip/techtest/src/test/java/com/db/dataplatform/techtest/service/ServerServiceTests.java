package com.db.dataplatform.techtest.service;

import static com.db.dataplatform.techtest.TestDataHelper.createTestDataEnvelopeApiObject;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;

import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.component.impl.ServerImpl;
import com.db.dataplatform.techtest.server.mapper.ServerMapperConfiguration;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.service.DataBodyService;

@RunWith(MockitoJUnitRunner.class)
public class ServerServiceTests {

	@Mock
	private DataBodyService dataBodyServiceImplMock;

	private ModelMapper modelMapper;
	@Mock
	private DataBodyEntity expectedDataBodyEntity;
	@Mock
	private DataEnvelope testDataEnvelope;

	private Server server;

	@Before
	public void setup() {
		ServerMapperConfiguration serverMapperConfiguration = new ServerMapperConfiguration();
		modelMapper = serverMapperConfiguration.createModelMapperBean();
		dataBodyServiceImplMock = mock(DataBodyService.class);
		expectedDataBodyEntity = mock(DataBodyEntity.class);
		testDataEnvelope = mock(DataEnvelope.class);
		testDataEnvelope = createTestDataEnvelopeApiObject();
		expectedDataBodyEntity = modelMapper.map(testDataEnvelope.getDataBody(), DataBodyEntity.class);
		expectedDataBodyEntity
				.setDataHeaderEntity(modelMapper.map(testDataEnvelope.getDataHeader(), DataHeaderEntity.class));

		server = new ServerImpl(dataBodyServiceImplMock, modelMapper);
	}

	@Test
	public void shouldSaveDataEnvelopeAsExpected() throws NoSuchAlgorithmException, IOException {

		expectedDataBodyEntity.setDataBody("cecfd3953783df706878aaec2c22aa70");
		when(dataBodyServiceImplMock.saveDataBody(any())).thenReturn(expectedDataBodyEntity);
		boolean success = server.saveDataEnvelope(testDataEnvelope);
		assertThat(success).isTrue();
	}
}
